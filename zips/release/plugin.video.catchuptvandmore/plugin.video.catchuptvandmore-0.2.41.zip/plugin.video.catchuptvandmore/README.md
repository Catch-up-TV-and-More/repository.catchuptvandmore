# Catch-up TV & More

<p align="center">
  <img src="https://github.com/Catch-up-TV-and-More/plugin.video.catchuptvandmore/raw/dev/icon.png" alt="Catch-up TV & More logo">
</p>

![CI](https://github.com/Catch-up-TV-and-More/plugin.video.catchuptvandmore/workflows/CI/badge.svg?branch=dev)

## Description
[Catch-Up TV & More](https://kodi.tv/addons/omega/plugin.video.catchuptvandmore) est un greffon vidéo pour le centre multimédia Kodi (ex XBMC).
Cette extension regroupe l'ensemble des vidéos des différents services et chaînes de rattrapage TV. De plus, cette extension vous permet d'accéder rapidement aux vidéos et contenus proposés par certains sites internet.
Catch-Up TV & More est compatible avec les versions de Kodi "19 Matrix" et supérieures.

*[Catch-Up TV & More](https://kodi.tv/addons/omega/plugin.video.catchuptvandmore) is a video addon for the Kodi media center (formerly XBMC).*
*This plugin brings together all the videos of various services and channels of catch-up TV. Furthermore, this addon allows you to quickly access the videos and content offered by certain websites.*
Catch-Up TV & More is compatible with Kodi "19 Matrix" and higher versions.

## Comment installer Catch-up TV & More — *How-to install Catch-up TV & More*

* **Français**: <https://catch-up-tv-and-more.github.io/fr/installation/>
* **English**: <https://catch-up-tv-and-more.github.io/installation/>

## Chaînes disponibles — *Available channels*

* **Français**: <https://catch-up-tv-and-more.github.io/fr/channels/>
* **English**: <https://catch-up-tv-and-more.github.io/channels/>

## Sites internet disponibles — *Available Websites*

* **Français**: <https://catch-up-tv-and-more.github.io/fr/websites/>
* **English**: <https://catch-up-tv-and-more.github.io/websites/>

## Bugs et améliorations — *Bugs and improvements*
Retours de bugs, propositions d'améliorations ou d'ajout de contenus sont les bienvenus ! GitHub.
⚠️Veuillez tester la dernière version beta avant de soumettre un bug.⚠️

*Bug reports, suggestions for improvements and content additions are welcome! GitHub.*
*⚠️Please try the latest beta version before issuing a bug.⚠️*


## Forums

* **Français**: <https://forum.mpdb.tv/index.php/topic,35713.0.html>
* **English**: <https://forum.kodi.tv/showthread.php?tid=307107>
